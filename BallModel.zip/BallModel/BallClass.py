#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Apr  7 13:36:43 2021

@author: danielchapman
"""
##############################################################################      
############################################################################## 
##############################################################################      
##############################################################################  

## THIS SCRIPT CONTAINS THE BALL AND STICK CELL CLASS, INSERTING CHANNELS,  ##
## AND TAKES PARAMETERS LISTED IN THE __init__                              ##

##############################################################################      
############################################################################## 
##############################################################################      
############################################################################## 
#%%
##############################################################################      
##############################################################################   
     
        ### Import Modules
        
##############################################################################      
############################################################################## 
from neuron import h,load_mechanisms,hclass
import numpy as np
import matplotlib.pyplot as plt
h.load_file('stdrun.hoc')


#%% import the morphology 
##############################################################################      
##############################################################################   
     
        ### Import morohology and mechanisms 
        
##############################################################################      
############################################################################## 
######### UNCOMMENT OUT THIS LINE IN THE FIRST TIME RUNNING THE CODE #########
######### TO LOAD THE MECHANISM, THEN YOU CAN COMMENT IT OUT SO      #########
######### THE KERNEL DOENSN' NEED TO BE RESTARTED EACH TIME IT'S RUN #########
######### OR JUST RESTART THE KERNEL OR ELSE AN ERROR WILL BE THROWN #########
load_mechanisms('/Users/danielchapman/PythonDev/Final/Mechanism/')
# load_mechanisms('/home/dpc53/BallModel/Mechanism/')
# h.load_file('/Users/danielchapman/PythonDev/Final/Morphology/Neuron3Oblique.hoc')


#%% 
##############################################################################      
##############################################################################   
     
        ### Create cell class from NEURON template and setup biophysical 
        ### framework 
        
##############################################################################      
############################################################################## 
class Cell:
    conductance_based = True
    parameter_names = []
    # def __init__(self,**parameters): # intialize the cell
    def __init__(self,soma_ra,cm, Rm,Vleak,gnaSoma,gkdr,gkap,soma_caL,
                 soma_caR,soma_caN,soma_caT,soma_hbar,soma_km,soma_kdBG,
                 soma_kca):
        
        # create th morphology of the cell
        self.soma = h.Section(name='soma', cell=self)
        self.soma.L = self.soma.diam = 40
        
        self.dend = h.Section(name='dend', cell=self)
        self.dend.L = 100
        self.dend.diam = 1
        self.dend.nseg = 100
        self.dend.connect(self.soma)
        
        self.source_section = self.soma 
        self.source = self.source_section(0.5)._ref_v
        self.recording_time = False # for pyNN
        self.spike_times = h.Vector(0) # for pyNN
        
        
        ### setup self parameters to be passed in during optimization 
        self.soma_ra = soma_ra    
        self.cm = cm
        self.Rm = Rm
        self.Vleak = Vleak
        self.gnaSoma = gnaSoma
        self.gkdr = gkdr
        self.gkap = gkap
        self.soma_caL = soma_caL
        self.soma_caR = soma_caR 
        self.soma_caN = soma_caN
        self.soma_caT = soma_caT
        self.soma_hbar = soma_hbar
        self.soma_km = soma_km
        self.soma_kdBG = soma_kdBG
        self.soma_kca = soma_kca 
    
        
        self._setup_biophysics() # call biophysics  
        # self.excitatory = h.ExpSyn(0.5, sec=self.soma[0])
        # self.inhibitory = h.ExpSyn(0.5, sec=self.soma[0])
        # for syn in self.excitatory, self.inhibitory:
        #     syn.tau = 2.0
        # self.excitatory.e = 0.0
        # self.inhibitory.e = -70.0
        self.v_init = -70.0 # for pyNN
        # self.parameter_names = ('soma_ra') # for pyNN
        self.traces = {} # for pyNN
        self.recording_time = False # for pyNN
        self.rec = h.NetCon(self.source, None, sec=self.source_section) # for pyNN
        
    def record_v(self, active): # for pyNN
        if active:
            self.vtrace = h.Vector()
            self.vtrace.record(self.source_section(0.5)._ref_v)
        if not self.recording_time:
            self.record_times = h.Vector()
            self.record_times.record(h._ref_t)
            self.recording_time += 1
        else:
            self.vtrace = None
            self.recording_time -= 1
        if self.recording_time == 0:
            self.record_times = None
    
    def record(self, active): # for pyNN 
        if active:
            self.rec = h.NetCon(self.source, None, sec=self.source_section)            
            self.rec.record(self.spike_times)
        
    def memb_init(self, v_init=None): # for pyNN 
        if v_init:
            self.v_init = v_init
            assert self.v_init is not None, "cell is a %s" 
            self.__class__.__name__
        for seg in self.soma:
            seg.v = self.v_init
      
    def _setup_biophysics(self): # setup biophysics
##############################################################################      
##############################################################################   
     
        ### Let's start with intrinsic parameters 
        
##############################################################################      
##############################################################################  
            
        soma_ra = self.soma_ra
        # soma_ra = 100 # axial resistance for soma

        # cm = 1 # membrane capacitance
        cm = self.cm
        # Rm = 30000 # membrane resistance (used for passive conductance)
        Rm = self.Rm
        # Vleak = -65 # reversal potential for passive
        Vleak = self.Vleak
       
##############################################################################      
##############################################################################   
     
        ### Major voltage gated Na and K currents, all channels from Spruston
        
##############################################################################      
##############################################################################  
        # gnaSoma = 0.015 # NaV conductance in soma 
        gnaSoma = self.gnaSoma
        
        # gkdr = 0.3*gnaSoma # delayed rectifier K current expressed as perecentage of gNa
        gkdr = self.gkdr 
        # setgk = 0.15*gnaSoma

        # gkap = setgk # proximal A type current conductance
        gkap = self.gkap
        # gkad = setgk # distal A type current conductance 
        
        
##############################################################################      
##############################################################################   
     
        ### Accessory currents all channels from aged 
        
##############################################################################      
##############################################################################  
        # soma_caL = 0.000075 # L type calcium 
        soma_caL = self.soma_caL
        # soma_caR = 0.00015 # R type calcium 
        soma_caR = self.soma_caR
        # soma_caN = 0.00001 # N type calcium 
        soma_caN = self.soma_caN 
        # soma_caT = 0.00015 # T type calcium 
        soma_caT = self.soma_caT
        # soma_hbar = 0.0001 # funny current
        soma_hbar = self.soma_hbar
        # soma_km = 0.000005 # m type potassium current
        soma_km = self.soma_km
        # mykca_init = 0.0001
        # soma_kdBG = 0.0001 # somatic d type potassium current
        soma_kdBG = self.soma_kdBG
        # kdBG_init = 0.001  # altering d type currrent in dendrites
        # kdBG_init = self.kdBG_init
        # soma_kca = 0.00001 # calcium dependent k current 
        soma_kca = self.soma_kca 
        # kir_gkbar = 0.0000001 # inward rectifying potassium from DG paper

##############################################################################      
##############################################################################   
     
        ### Insert channels into soma and set conductances
        
##############################################################################      
##############################################################################  
        self.soma.insert('pas') # standard neuron mechanism
        self.soma.Ra = soma_ra
        self.soma.cm = cm
        # self.soma.insert('hh')
        self.soma.insert('nax') # from spruston et al.
        self.soma.insert('kdr') # from spruston et al.
        self.soma.insert('kap') # from spruston et al.
        self.soma.insert('cal') # from aged 
        self.soma.insert('can') # from aged 
        self.soma.insert('car') # from aged
        self.soma.insert('cat') # from aged
        # self.soma.insert('cad') # from aged
        # self.soma.insert('cadL') # from aged
        # self.soma.insert('cadN') # from aged
        self.soma.insert('h') # from aged
        self.soma.insert('kdBG') # from aged
        self.soma.insert('km') # from aged
        self.soma.insert('kca') # from aged
        # self.soma.insert('mykca') # from aged

        for seg in self.soma:     
            seg.pas.g = 1/Rm
            seg.pas.e = Vleak
            seg.nax.gbar = gnaSoma
            seg.nax.ar2 = 0.8
            seg.kdr.gkdrbar = gkdr
            seg.kap.gkabar = gkap
            seg.cal.gcalbar = soma_caL
            seg.can.gcalbar = soma_caN
            seg.car.gcabar = soma_caR
            seg.cat.gcatbar = soma_caT
            seg.h.gbar = soma_hbar
            # seg.h.vhalf = -82
            seg.km.gbar = soma_km
            seg.kdBG.gbar = soma_kdBG
            seg.kca.gbar = soma_kca
            # seg.mykca.gkbar = mykca_init
            seg.eca = 137
            seg.ena = 55
            seg.ek = -80

        self.dend.insert('pas')
        self.dend.insert('nax')
        self.dend.insert('kdr')
        self.dend.insert('kap') # from spruston et al.
        self.dend.insert('cal') # from aged 
        self.dend.insert('can') # from aged 
        self.dend.insert('car') # from aged
        self.dend.insert('cat') # from aged
        # self.soma.insert('cad') # from aged
        # self.soma.insert('cadL') # from aged
        # self.soma.insert('cadN') # from aged
        self.dend.insert('h') # from aged
        self.dend.insert('kdBG') # from aged
        # self.dend.insert('km') # from aged
        self.dend.insert('kca') # from aged
        self.dend.Ra = 100
        
        
        gh_end = 7*soma_hbar
        h_dhalf = 280   
        h_steep = 50
        for seg in self.dend:
            xdist = h.distance(self.soma(0.5), seg) # neuron 2
            dhalf = 100
            steep = 50
            Rm_end = 1000
            Rm_sigmoid = Rm + (Rm_end - Rm)/(1+np.exp((dhalf-xdist)/steep))
            seg.pas.g = 1/Rm_sigmoid
            # print(Rm_sigmoid)
            
            seg.pas.e = Vleak
            seg.nax.gbar = gnaSoma
            # seg.nax.ar2 = 0.8
            seg.kdr.gkdrbar = gkdr
            seg.kap.gkabar = gkap
            seg.cal.gcalbar = soma_caL
            seg.can.gcalbar = soma_caN
            seg.car.gcabar = soma_caR
            # seg.cat.gcatbar = soma_caT
            seg.h.gbar = soma_hbar + (gh_end - soma_hbar)/(1.0 + np.exp((h_dhalf-xdist)/h_steep))
            # seg.h.vhalf = -82
            # seg.km.gbar = soma_km
            seg.kdBG.gbar = soma_kdBG
            seg.kca.gbar = soma_kca
            # seg.mykca.gkbar = mykca_init
            seg.eca = 137
            seg.ena = 55
            seg.ek = -80
        
            #### from aged ####                
# /* Inserting LVA Ca++ T-type channels along the apical trunk in
# a linearly increasing manner, for xdist > 50 um 
# */
            
            caT_distal_distance = 100 # distance for maximum conductance
            caT_proximal_distance = 50 # distance in dendrites for maxiumu cond.
            fr = xdist/caT_distal_distance
            if xdist < caT_proximal_distance: 
                seg.cat.gcatbar = soma_caT/10
            elif xdist < caT_distal_distance:
                seg.cat.gcatbar = soma_caT*(1+2.4*fr)
            else:
                seg.cat.gcatbar = soma_caT*3.4
                            ### from aged ###
#/* Inserting HVAm Ca++ R-type and N-type, and HVA L-type channesls along
# the apical trunk. The R-type current is distributed as T-type current, in 
# a linearly increasing manner, for xdist < 100 um. 
# The L-type current is distributed in a 
# linearly decreasing conductance for distances xdist  < 50 um
# while the N-type current is distributed in a
# fixed conductance, as does L-type for distances xdist  > 50 um
# */
            caR_distal_distance = 100
            fr = xdist/caR_distal_distance
            if xdist < 50:      
                seg.car.gcabar = soma_caR/2
            elif xdist < caR_distal_distance:
                seg.car.gcabar = soma_caR*(1+5*fr)
            else:
                seg.car.gcabar = soma_caR*6

            caL_distal_distance = 50
            if xdist < caL_distal_distance:
                seg.cal.gcalbar = soma_caL*(1-2.*fr/3.)
                seg.can.gcalbar = soma_caN*(1-2.*fr/3.)
            else:
                seg.cal.gcalbar = soma_caL/6.
                seg.can.gcalbar = soma_caN/4.











# m = Cell(soma_ra = 100,
# cm = 1.2,
# Rm = 36182,
# Vleak = -67,
# gnaSoma = 0.001,
# gkdr = 0.005,
# gkap = 0.005,
# soma_caL = 0.0001,
# soma_caR = 0.001,
# soma_caN = 0.0001,
# soma_caT = 0.0001,
# soma_hbar = 0.000001,
# soma_km = 0.000001,
# soma_kdBG = 0.000001,
# soma_kca = 0.000001)


#%%
# clamp = h.IClamp(m.soma(0.5)) 
# stim_start = 100
# stim_end = 500
# clamp.amp = 0.05
# clamp.delay = stim_start
# clamp.dur = 400

# # recording paremeters 
# voltage = h.Vector()
# voltage.record(m.soma(0.5)._ref_v)
# h.celsius = 20
# time = h.Vector()
# time.record(h._ref_t)
# h.tstop = 800
# h.finitialize(-70) # initial potential 
# h.run()

# plt.plot(time,voltage)