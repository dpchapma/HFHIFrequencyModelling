#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri May 14 14:08:43 2021

@author: danielchapman
"""
##############################################################################      
############################################################################## 
##############################################################################      
##############################################################################  

## THIS SCRIPT EXTRACTS FREQUENCY DATA OUTPUT FROM THE GENETIC ALGORITHM IN ##
## BY TAKING PARAMETERS IN CSV AND OUTPUTTING A CSV WITH SPIKE COUNTS       ##
## IN ANOTHER CSV                                                           ##

##############################################################################      
############################################################################## 
##############################################################################      
##############################################################################
#%%
##############################################################################      
##############################################################################   
     
        ### Import Modules
        
##############################################################################      
############################################################################## 
import numpy as np
from Run_sim import Run_sim
from BallClassCN import Cell
import pandas as pd

#%%
##############################################################################      
##############################################################################   
     
        ### Define some matrices we'll need for later 
        
##############################################################################      
############################################################################## 

SimData = np.zeros([16,4])
StimInt = [0,0.075,0.135,0.195]


#%%
##############################################################################      
##############################################################################   
     
        ### Define the function (takes path to csv with parameters and outputs
        ### frequency data)
        
##############################################################################      
############################################################################## 
def Extract_frequency(PathToParams):
    parameters = np.genfromtxt(PathToParams, delimiter=',')
    
    
    Freq_dat = np.zeros([len(StimInt),len(parameters.T)])
    AP_amp = np.zeros([len(StimInt),len(parameters.T)])
    VB = np.zeros([len(StimInt),len(parameters.T)])
    AHP_DA = np.zeros([len(StimInt),len(parameters.T)])
    AHP_DS = np.zeros([len(StimInt),len(parameters.T)])
    AHP_ST = np.zeros([len(StimInt),len(parameters.T)])
    AHP_D = np.zeros([len(StimInt),len(parameters.T)])
    AHP_TFP = np.zeros([len(StimInt),len(parameters.T)])
    AP_HW = np.zeros([len(StimInt),len(parameters.T)])
    AP_W = np.zeros([len(StimInt),len(parameters.T)])
    SSVSE = np.zeros([len(StimInt),len(parameters.T)])
    SSV = np.zeros([len(StimInt),len(parameters.T)])
    DT = np.zeros([len(StimInt),len(parameters.T)])
    IFS = np.zeros([len(StimInt),len(parameters.T)])
    ILS = np.zeros([len(StimInt),len(parameters.T)])
    for i in range(0,len(parameters.T)):
        m = Cell(soma_ra = parameters[0,i],
        cm = parameters[1,i],
        Rm = parameters[2,i],
        Vleak = parameters[3,i],
        gnaSoma = parameters[4,i],
        gkdr = parameters[5,i],
        gkap = parameters[6,i],
        soma_caL = parameters[7,i],
        soma_caR = parameters[8,i],
        soma_caN = parameters[9,i],
        soma_caT = parameters[10,i],
        soma_hbar = parameters[11,i],
        soma_km = parameters[12,i],
        soma_kdBG = parameters[13,i],
        soma_kca = parameters[14,i], CN = i)
        
        for x in range (0,len(StimInt)):
            SimData[:,x] = Run_sim(StimAmp = StimInt[x],m=m)
            
            'Return of Run sim, looking for frequency so RunSim of 0'
    #         return Spikecount,Spikecount_stimint,\
    # AP_amplitude, voltage_base,AHP_depth_abs,\
    # AHP_depth_abs_slow,AHP_slow_time,AHP_depth,AHP_time_from_peak,\
    # AP_duration_half_width, AP_width,steady_state_voltage_stimend,\
    # steady_state_voltage, decay_time_constant_after_stim
            
    
    ##### DO THIS FOR ALL THE FEATURES SO I CAN REGRESS THEM BACK TO FREQUENCY
            Freq_dat[x,i] = SimData[0,x]
            AP_amp[x,i] = SimData[2,x]
            VB[x,i] = SimData[3,x]
            AHP_DA[x,i] = SimData[4,x]
            AHP_DS[x,i] = SimData[5,x]
            AHP_ST[x,i] = SimData[6,x]
            AHP_D[x,i] = SimData[7,x]
            AHP_TFP[x,i] = SimData[8,x]
            AP_HW[x,i] = SimData[9,x]
            AP_W[x,i] = SimData[10,x]
            SSVSE[x,i] = SimData[11,x]
            SSV[x,i] = SimData[12,x]
            DT[x,i] = SimData[13,x]
            IFS[x,i] = SimData[14,x]
            ILS[x,i] = SimData[15,x]
            
    return Freq_dat, AP_amp, VB, AHP_DA, AHP_DS, AHP_ST, AHP_D, AHP_TFP, AP_HW,\
        AP_W, SSVSE, SSV, DT, IFS, ILS


#%%
##############################################################################      
##############################################################################   
     
        ### Let's run the script and output resulting data to csv for MATLAB
        
##############################################################################      
############################################################################## 
PathToParams = '/Users/danielchapman/Desktop/05.12.BallStickResults/05.18.Round2Results/Results/Ball200MSGenTestHofParams.csv'
FREQ = Extract_frequency(PathToParams)



# df = pd.DataFrame(data=FREQ)

# # df = (df.T)

# # print (df)

# df.to_excel('05.18.Round2.FREQ.xlsx')


