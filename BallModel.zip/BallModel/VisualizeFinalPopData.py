#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Jan  7 15:32:47 2021

@author: danielchapman
"""
##############################################################################      
############################################################################## 
##############################################################################      
##############################################################################  

## THIS SCRIPT VISUALIZES OUTPUT FROM THE GENETIC ALGORITHM IN deap_efel.py ##

##############################################################################      
############################################################################## 
##############################################################################      
##############################################################################

#%%
##############################################################################      
##############################################################################   
     
        ### Import Modules
        
##############################################################################      
############################################################################## 
import numpy as np
from BallClassCN import Cell
from neuron import h
import matplotlib.pyplot as plt 
import efel
h.load_file('stdrun.hoc')

#%%
#%%
##############################################################################      
##############################################################################   
     
        ### Define the function
        
##############################################################################      
############################################################################## 
def Visualize_data(PathToParams):
    parameters = np.genfromtxt(PathToParams, delimiter=',')



    # for i in range (0,len(parameters[1,:])):
    for i in range (100,105):
        m = Cell(soma_ra = parameters[0,i],
        cm = parameters[1,i],
        Rm = parameters[2,i],
        Vleak = parameters[3,i],
        gnaSoma = parameters[4,i],
        gkdr = parameters[5,i],
        gkap = parameters[6,i],
        soma_caL = parameters[7,i],
        soma_caR = parameters[8,i],
        soma_caN = parameters[9,i],
        soma_caT = parameters[10,i],
        soma_hbar = parameters[11,i],
        soma_km = parameters[12,i],
        soma_kdBG = parameters[13,i],
        soma_kca = parameters[14,i], CN = i)
        
        
        clamp = h.IClamp(m.soma(0.5)) 
        stim_start = 200
        stim_end = 600
        clamp.amp = 0.195
        clamp.delay = stim_start
        clamp.dur = 400
        
        # stim = h.IClamp(m.soma(0.5)) # neuron 2
        # Stim = 0.1
        # stim.amp = Stim
        t = h.Vector().record(h._ref_t) # record time steps  
        # stim.delay = 100 # delay of stimulation (ms)
        # stim.dur = 400 # duration of stimulation (ms)  
        # create vectors to record
        # voltage vectors
        soma_v = h.Vector().record(m.soma(0.5)._ref_v)
        # dend_v = h.Vector().record(m.apic[10](0.5)._ref_v)
        # action potential vectors
        soma_AP = h.APCount(m.soma(0.5))

        h.celsius = 20
        h.finitialize(-70) # initial potential 
        h.continuerun(1000)
        f = plt.figure()
        plt.plot(t,soma_v,linewidth=0.5)
        print(soma_AP)
        trace = {}
        trace['T'] = t
        trace['V'] = soma_v
        trace['stim_start'] = [stim_start]
        trace['stim_end'] = [stim_end]
        traces = [trace]
    
    # setup feature extraction 
        features = efel.getFeatureValues(traces, ["Spikecount",
                                              "Spikecount_stimint",
                                              "AP_amplitude","AP1_amp",
                                              "AP2_amp","APlast_amp",
                                              "AP_duration_half_width",
                                              "AP_width","AHP_depth_abs",
                                              "AHP_depth_abs_slow",
                                              "AHP_slow_time","AHP_depth",
                                              "AHP_time_from_peak",
                                              "voltage_base",
                                              "steady_state_voltage_stimend",
                                              "steady_state_voltage",
                                              "decay_time_constant_after_stim"
                                              ])
    



        # Spikecount = features[0]["Spikecount"][0]
        # decay_time = features[0]["decay_time_constant_after_stim"][0]
        spikecount = features[0]['Spikecount']
        print(spikecount)
        # print(decay_time)
    # plt.show()
    return features
    
    # Stim = 0.18
    # # plot at different injection levels
    # f = plt.figure()
    # i = 0 
    # for x in np.linspace(0,Stim,9):
    #     clamp.amp = x 
    #     h.celsius = 20
    #     h.finitialize(-70) # initial potential 
    #     h.continuerun(600)
    #     plt.plot(t,soma_v)
    #     somaAPC[i] = soma_AP.n
    #     i = i + 1
    #     plt.show()

    #     # plot frequency curve
    #     HzFactor = (1000/clamp.dur)
    #     f2 = plt.figure()
    #     plt.plot(APCX, somaAPC*HzFactor,'bo')


#%%

# # visualize the parameters
# PathToParams = '/Users/danielchapman/PythonDev/Final/Models/BallModel/Ball5GenTestParams.csv'
# Visualize_data(PathToParams)

#%%
PathToParams = '/Users/danielchapman/Desktop/05.12.BallStickResults/05.25.1000GenResults/Results/Ball1000MSGenTestHofParams.csv'
# PathToParams = '/Users/danielchapman/Desktop/Computational PCA/Ball100GenTestHofParams.csv'
Blah = Visualize_data(PathToParams)

