#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Jan 22 12:34:22 2021

@author: danielchapman
"""

##############################################################################      
############################################################################## 
##############################################################################      
##############################################################################  

## THIS SCRIPT RUNS SIM ON MY CELL AND GETS SAME FEATURES WE GET FROM REAL  ##
## CELL. TAKES STIMULUS AMPLITUDE AS ARGUMENT                               ##                           

##############################################################################      
############################################################################## 
##############################################################################      
##############################################################################

#%%
##############################################################################      
##############################################################################   
     
        ### Import Modules
        
##############################################################################      
############################################################################## 
from neuron import h
h.load_file('stdrun.hoc')
import efel
import numpy as np

#%%
##############################################################################      
##############################################################################   
     
        ### Define the function
        
##############################################################################      
############################################################################## 

def Run_sim(StimAmp, m):
    '''
    Function Run_sim
    Inputs
    StimAmp: stimulus amplitude
    m: neuron cell class
    
    Outputs a tuple of 22 differrent features obtained from the stimulation
    in this order: 
    Spikecount,Spikecount_stimint,\
    AP_amplitude, voltage_base,AHP_depth_abs,\
    AHP_depth_abs_slow,AHP_slow_time,AHP_depth,AHP_time_from_peak,\
    AP_duration_half_width,steady_state_voltage_stimend,\
    steady_state_voltage, decay_time_constant_after_stim, inv_time_to_first_spike,\
    inv_last_ISI, inv_first_ISI, inv_second_ISI, inv_third_ISI, inv_fourth_ISI,\
    AP_rise_rate, AP_peak_downstroke,AP_width
    '''
    # setup stimulation paraemeters 
    clamp = h.IClamp(m.soma(0.5)) 
    stim_start = 200
    stim_end = 600
    clamp.amp = StimAmp
    clamp.delay = stim_start
    clamp.dur = 400
    
    # recording paremeters 
    voltage = h.Vector()
    voltage.record(m.soma(0.5)._ref_v)
    h.finitialize(-70) # initial potential 
    h.celsius = 20
    time = h.Vector()
    time.record(h._ref_t)
    h.tstop = 700
    h.run()
    
    # setup trace for efel input for feature extraction
    trace = {}
    trace['T'] = time
    trace['V'] = voltage
    trace['stim_start'] = [stim_start]
    trace['stim_end'] = [stim_end]
    traces = [trace]
    
    # setup feature extraction 
    features = efel.getMeanFeatureValues(traces, ["Spikecount_stimint",
                                      "AP_amplitude_from_voltagebase",
                                      "voltage_base","AHP_depth_abs",
                                      "AHP_depth_abs_slow",
                                      "AHP_slow_time","AHP_depth",
                                      "AHP_time_from_peak",
                                      "AP_duration_half_width",
                                      "steady_state_voltage_stimend",
                                      "steady_state_voltage",
                                      "decay_time_constant_after_stim",
                                      "inv_time_to_first_spike",
                                      "inv_last_ISI","Spikecount",
                                      "inv_first_ISI","inv_second_ISI",
                                      "inv_third_ISI","inv_fourth_ISI",
                                      "AP_rise_rate",
                                      "AP_peak_downstroke",'AP_width'
                                      ])
    

    try:
        inv_first_ISI = features[0]["inv_first_ISI"]
    except:
        inv_first_ISI = 0
        
    try:
        inv_second_ISI = features[0]["inv_second_ISI"]
    except:
        inv_second_ISI = 0
        
    try:
        inv_third_ISI = features[0]["inv_third_ISI"]
    except:
        inv_third_ISI = 0
    
    try:
        inv_fourth_ISI =features[0]["inv_fourth_ISI"]
    except:
        inv_fourth_ISI = 0
    
    try:
        AP_rise_rate = features[0]["AP_rise_rate"]
    except:
        AP_rise_rate = 0
        
    try:
        AP_peak_downstroke = features[0]["AP_peak_downstroke"]
    except:
        AP_peak_downstroke = 0
    
    try: 
        inv_time_to_first_spike = features[0]["inv_time_to_first_spike"]
    except:
        inv_time_to_first_spike = 0
        
        
    try:
        inv_last_ISI = features[0]["inv_last_ISI"]
    except:
        inv_last_ISI = 0
    
    
    Spikecount = features[0]["Spikecount"]
    Spikecount_stimint = features[0]["Spikecount_stimint"]
    print(Spikecount)
    
    # AP_amplitude = features[0]["AP_amplitude"]
    # print(AP_amplitude)
    # print(type(AP_amplitude))
    # if AP_amplitude is None:
    #     AP_amplitude = 0
    # elif AP_amplitude == []:
    #     AP_amplitude = 0
    # else:
    #     AP_amplitude = features[0]["AP_amplitude"][0]
    try:
        AP_amplitude = features[0]["AP_amplitude_from_voltagebase"]
    except:
        AP_amplitude = 0
        
    # AP1_amp = features[0]["AP1_amp"][0]
    # AP2_amp = features[0]["AP2_amp"][0]
    
    # APlast_amp = features[0]["APlast_amp"]
    # if APlast_amp is None:
    #     APlast_amp = 0
    # else:
    #     APlast_amp = features[0]["APlast_amp"] 
    
    # AHP_depth_abs_slow = features[0]["AHP_depth_abs_slow"]
    # if AHP_depth_abs_slow is None:
    #     AHP_depth_abs_slow = 0
    # else: 
    #     AHP_depth_abs_slow = features[0]["AHP_depth_abs_slow"][0]     
    
    try:
        AHP_depth_abs_slow = features[0]["AHP_depth_abs_slow"]
    except:
        AHP_depth_abs_slow = 0
    
    
    
    # AHP_depth_abs = features[0]["AHP_depth_abs"]
    # if AHP_depth_abs is None:
    #     AHP_depth_abs = 0
    # else:
    #     AHP_depth_abs = features[0]["AHP_depth_abs"][0]
    
    try:
        AHP_depth_abs = features[0]["AHP_depth_abs"]
    except:
        AHP_depth_abs = 0
    
    
    
    # AHP_slow_time = features[0]["AHP_slow_time"]
    # if AHP_slow_time is None:
    #     AHP_slow_time = 0
    # else:
    #     AHP_slow_time = features[0]["AHP_slow_time"][0]
    
    try:
        AHP_slow_time = features[0]["AHP_slow_time"]
    except:
        AHP_slow_time = 0
    
    
    # AHP_depth = features[0]["AHP_depth"]
    # if AHP_depth is None:
    #     AHP_depth = 0
    # else:
    #     AHP_depth = features[0]["AHP_depth"][0]
    
    try:
        AHP_depth = features[0]["AHP_depth"]
    except:
        AHP_depth = 0
    
    # AHP_time_from_peak = features[0]["AHP_time_from_peak"]
    # if AHP_time_from_peak is None:
    #     AHP_time_from_peak = 0
    # else:
    #     AHP_time_from_peak = features[0]["AHP_time_from_peak"][0]
    
    try:
        AHP_time_from_peak = features[0]["AHP_time_from_peak"]
    except:
        AHP_time_from_peak = 0
    # AP_duration_half_width = features[0]["AP_duration_half_width"]
    # if AP_duration_half_width is None:
    #     AP_duration_half_width = 0
    # else:
    try:
        AP_duration_half_width = features[0]["AP_duration_half_width"]
    except:
        AP_duration_half_width = 0
    
    # AP_width = features[0]["AP_width"]
    # if AP_width is None:
    #     AP_width = 0
    # else:
    #     AP_width = features[0]["AP_width"][0]
    
    
    try:
        AP_width = features[0]["AP_width"]
    except:
        AP_width = 0
        
    voltage_base = features[0]["voltage_base"]
    steady_state_voltage_stimend = features[0]["steady_state_voltage_stimend"]
    steady_state_voltage = features[0]["steady_state_voltage"]
    decay_time_constant_after_stim = features[0]["decay_time_constant_after_stim"]
    # ohmic_input_resistance= features[0]["ohmic_input_resistance"][0]
    
    # return the features
    return Spikecount,Spikecount_stimint,\
    AP_amplitude, voltage_base,AHP_depth_abs,\
    AHP_depth_abs_slow,AHP_slow_time,AHP_depth,AHP_time_from_peak,\
    AP_duration_half_width,steady_state_voltage_stimend,\
    steady_state_voltage, decay_time_constant_after_stim, inv_time_to_first_spike,\
    inv_last_ISI, inv_first_ISI, inv_second_ISI, inv_third_ISI, inv_fourth_ISI,\
    AP_rise_rate, AP_peak_downstroke,AP_width
    
    
    # return features
    
    # order from get data
      #     return SC,SCSI, AP_amp, VB, AHPDAbs, AHPDAbslow, AHPSlowT, AHPD, AHPTFP,\
    # APHW, APW, SSVSE, SSV, DTC, ITFS, ITLS, IFIS, ISIS, ITIS, IFoIS, APRT,\
    # ADUS  

from BallClass import Cell
m = Cell(soma_ra = 100,
cm = 1.2,
Rm = 36182,
Vleak = -67,
gnaSoma = 0.001,
gkdr = 0.005,
gkap = 0.005,
soma_caL = 0.0001,
soma_caR = 0.001,
soma_caN = 0.0001,
soma_caT = 0.0001,
soma_hbar = 0.000001,
soma_km = 0.000001,
soma_kdBG = 0.000001,
soma_kca = 0.000001) 
# SimData[:,1] = Run_sim(StimAmp = 0.195,m=m)
Blah = Run_sim(StimAmp = 0.15, m=m)
    
    
    