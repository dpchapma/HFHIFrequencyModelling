#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Apr 29 16:58:53 2021

@author: danielchapman
"""
from neuron import h,load_mechanisms
load_mechanisms('/home/dpc53/BallModel/Mechanism/')

from BallClass import Cell

h.v_init = -70
m = Cell(1,1,1,1,1,1,1,1,1,1,1,1,1,1,1)
clamp = h.IClamp(m.soma(0.5)) 
stim_start = 100
stim_end = 500
StimAmp = 0.1
clamp.amp = StimAmp
clamp.delay = stim_start
clamp.dur = 400

# recording paremeters 
voltage = h.Vector()
voltage.record(m.soma(0.5)._ref_v)
h.celsius = 20
time = h.Vector()
time.record(h._ref_t)
h.tstop = 600
h.run()