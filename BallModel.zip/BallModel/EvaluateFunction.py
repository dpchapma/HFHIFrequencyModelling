#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Jan  5 12:39:26 2021

@author: danielchapman
"""
##############################################################################      
############################################################################## 
##############################################################################      
##############################################################################  

## THIS SCRIPT CONTAINS EVALUAT FUNCTION FOR GENETIC ALGORITHM              ##
## code modified from bluebrain EFEL github                                 ##

##############################################################################      
############################################################################## 
##############################################################################      
##############################################################################

#%%
##############################################################################      
##############################################################################   
     
        ### Import Modules
        
##############################################################################      
############################################################################## 
from neuron import h
h.load_file('stdrun.hoc')
from BallClass import Cell
import numpy as np
from GetData import get_data

#%%
##############################################################################      
##############################################################################   
     
        ### DEFINE FUNCTION
        
##############################################################################      
############################################################################## 
# PathToFolder ='/Users/danielchapman/Desktop/StephCCDat/Sham/' 
PathToFolder = '/home/dpc53/BallModel/StephCCDat/Sham'

def evaluate(individual,ExpData = get_data(PathToFolder),gen_index = None):

    """
    Evaluate a neuron model with parameters, extracts
    eFeatures from resulting traces and returns a tuple of "Data out"
    Takes path to folder of experimental data of abf files for feature extraction
    """
    # Create cell class with parameters set as deap "individual" classes and
    # initialize to -70
    h.v_init = -70
    m = Cell(soma_ra = individual[0],
    cm = individual[1],
    Rm = individual[2],
    Vleak = individual[3],
    gnaSoma = individual[4],
    gkdr = individual[5],
    gkap = individual[6],
    soma_caL = individual[7],
    soma_caR = individual[8],
    soma_caN = individual[9],
    soma_caT = individual[10],
    soma_hbar = individual[11],
    soma_km = individual[12],
    soma_kdBG = individual[13],
    soma_kca = individual[14])
    
    
    
    # Setup simulation data structure and iterate over stim intensities using
    # RunSim function
    SimData = np.zeros([21,4])
    # StimInt = [0,0.035,0.055,0.075,0.095,0.115,0.135,0.155,0.175,0.195]
    # StimInt = [0,0.075,0.135,0.195]
    StimInt = [0,0.075,0.135,0.195]
    from Run_sim import Run_sim
    for i in range (0,len(StimInt)):
        SimData[:,i] = Run_sim(StimAmp = StimInt[i],m=m)
        
        # print(SimData)
    
    
    # Setup a fitness function that returns data as a "soft" z-score (using 0.5 STD)
    def FitnessFun(RStimLev,SStimLev,Feat,SimData,RealData,Thresh):
        if RealData[Feat][1,RStimLev] == 0:
            Error = abs(SimData[Feat,SStimLev]-RealData[Feat][0,RStimLev])
            return Error
        else:
            AbsDif = abs(SimData[Feat,SStimLev]-RealData[Feat][0,RStimLev])
            Error = (AbsDif/RealData[Feat][1,RStimLev]) - Thresh*RealData[Feat][1,RStimLev]
            # Error = AbsDif/RealData[Feat][1,StimLev]
            if Error<0:
                return 0
            else:
                return Error
    # setup data output structure and set array to fitness function for each
    # stim level and feature 
    DataOut = np.zeros(17)

    # Spikecount at traces 0,4,7,9
    DataOut[0] = (FitnessFun(0,0,0,SimData,ExpData,0.3))
    # DataOut[1] = (FitnessFun(1,0,SimData,ExpData))
    # DataOut[2] = (FitnessFun(2,0,SimData,ExpData))
    DataOut[1] = (FitnessFun(3,1,0,SimData,ExpData,0.3))
    # DataOut[4] = (FitnessFun(4,0,SimData,ExpData))
    # DataOut[5] = (FitnessFun(5,0,SimData,ExpData))
    DataOut[2] = (FitnessFun(6,2,0,SimData,ExpData,0.3))
    
    # Introduce penalty if there is no spiking 
    if DataOut[2] > 0:
        DataOut[2] = 1000
        DataOut[3] = 1000
        DataOut[4] = 1000
        DataOut[5] = 1000
        DataOut[6] = 1000
        DataOut[7] = 1000
        DataOut[8] = 1000
        DataOut[9] = 1000
        DataOut[10] = 1000
        DataOut[11] = 1000
        DataOut[13] = 1000
        DataOut[14] = 1000
        DataOut[15] = 1000     
        DataOut[16] = 1000
    
    else:
        # DataOut[7] = (FitnessFun(7,0,SimData,ExpData))
        # DataOut[8] = (FitnessFun(8,0,SimData,ExpData))
        DataOut[3] = (FitnessFun(9,3,0,SimData,ExpData,0.3))
        if DataOut[3] > 0:
            DataOut[3] = 1000        
            DataOut[4] = 1000
            DataOut[5] = 1000
            DataOut[6] = 1000
            DataOut[7] = 1000
            DataOut[8] = 1000
            DataOut[9] = 1000
            DataOut[10] = 1000
            DataOut[11] = 1000
            DataOut[13] = 1000
            DataOut[14] = 1000
            DataOut[15] = 1000     
            DataOut[16] = 1000
        else:
            
        # Spikecount stimint 
        # DataOut[10] = (FitnessFun(0,1,SimData,ExpData))
        # DataOut[11] = (FitnessFun(1,1,SimData,ExpData))
        # DataOut[12] = (FitnessFun(2,1,SimData,ExpData))
        # DataOut[13] = (FitnessFun(3,1,SimData,ExpData))
        # DataOut[14] = (FitnessFun(4,1,SimData,ExpData))
        # DataOut[15] = (FitnessFun(5,1,SimData,ExpData))
        # DataOut[16] = (FitnessFun(6,1,SimData,ExpData))
        # DataOut[17] = (FitnessFun(7,1,SimData,ExpData))
        # DataOut[18] = (FitnessFun(8,1,SimData,ExpData))
        # DataOut[19] = (FitnessFun(9,1,SimData,ExpData))
        
            # AP amp
            DataOut[4] = (FitnessFun(9,3,2,SimData,ExpData,0.1))
            
            # AHP DEPTH ABS 
            # DataOut[5] = (FitnessFun(9,3,4,SimData,ExpData,0.1))
            
            # # AHP DEPTH ABS SLOW
            # DataOut[6] = (FitnessFun(9,3,5,SimData,ExpData,0.1))
            
            # # AHP SLOW TIME 
            # DataOut[7] = (FitnessFun(9,3,6,SimData,ExpData,0.1))
            
            # AHP DEPTH
            DataOut[5] = (FitnessFun(9,3,7,SimData,ExpData,0.1))
            
            # AP DURATION HALF WIDTH
            DataOut[6] = (FitnessFun(9,3,9,SimData,ExpData,0))
            
            # AP WIDTH
            # DataOut[10] = (FitnessFun(9,3,10,SimData,ExpData,0))
            
            # Introduce penalties if voltage base and SSVE are greater than 1 SD away
            DataOut[7] = (FitnessFun(9,3,11,SimData,ExpData,0))
            if DataOut[7] > 1:
                DataOut[7] = 1000
            # Voltage base 
            DataOut[8] = (FitnessFun(9,3,3,SimData,ExpData,0))
            if DataOut[8] > 1:
                DataOut[8] = 1000
                
            # Inv to first spike
            DataOut[9] = (FitnessFun(9,3,12,SimData,ExpData,0.1))
            
            # Inv to last spike
            DataOut[10] = (FitnessFun(9,3,13,SimData,ExpData,0.1))
            
            # inv_first-fourth_ISI
            DataOut[11] = (FitnessFun(9,3,14,SimData,ExpData,0.1))
            DataOut[12] = (FitnessFun(9,3,15,SimData,ExpData,0.1))
            DataOut[13] = (FitnessFun(9,3,16,SimData,ExpData,0.1))
            DataOut[14] = (FitnessFun(9,3,17,SimData,ExpData,0.1))
            
            # AP_rise_rate
            DataOut[15] = (FitnessFun(9,3,18,SimData,ExpData,0.1))
            
            # AP_peak_downstroke
            DataOut[16] = (FitnessFun(9,3,19,SimData,ExpData,0.1))
    
    #Return total error as sum of all values
    TotError = np.zeros([1])
    TotError[0] = np.sum(DataOut)
    # ExpData 
    # return SC,SCSI, AP_amp, VB, AHPDAbs, AHPDAbslow, AHPSlowT, AHPD, AHPTFP,\
    # APHW, APW, SSVSE, SSV, DTC, ITFS, ITLS, IFIS, ISIS, ITIS, IFoIS, APUS,\
    # ADUS, APRT
    
    # return Spikecount,Spikecount_stimint,\
    # AP_amplitude, voltage_base,AHP_depth_abs,\
    # AHP_depth_abs_slow,AHP_slow_time,AHP_depth,AHP_time_from_peak,\
    # AP_duration_half_width, AP_width,steady_state_voltage_stimend,\
    # steady_state_voltage, decay_time_constant_after_stim, inv_time_to_first_spike,\
    # inv_last_ISI, inv_first_ISI, inv_second_ISI, inv_third_ISI, inv_fourth_ISI,\
    # AP_rise_rate, AP_peak_downstroke
    
    # print(type(DataOut))
    # print(DataOut)
    return DataOut

  
    
    
    

    