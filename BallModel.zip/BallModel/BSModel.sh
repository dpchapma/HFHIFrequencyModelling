#!/bin/bash
#SBATCH --job-name="BSModel"
#SBATCH --output="%x.o%j"
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=48
#SBATCH --time=06:00:00
#SBATCH --mem=5G
#SBATCH --mail-user=dpc53@georgetown.edu
#SBATCH --mail-type=END,FAILqk

module load anaconda3

source $(pwd)/test_env/bin/activate

python /home/dpc53/BallModel/deap_efel.py

