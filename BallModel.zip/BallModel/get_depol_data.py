#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Mar  7 21:17:09 2021

@author: danielchapman
"""

##############################################################################      
############################################################################## 
##############################################################################      
##############################################################################  

## THIS SCRIPT GETS OUTPUT FROM CCIV depolarizing DATA USING efel        ##

##############################################################################      
############################################################################## 
##############################################################################      
##############################################################################

#%%
##############################################################################      
##############################################################################   
     
        ### Import Modules
        
##############################################################################      
############################################################################## 
import pyabf
import numpy as np
import matplotlib.pyplot as plt 
import efel

#%%
##############################################################################      
##############################################################################   
     
        ### Define function to get data from hyperpolarizing steps using efel
        
##############################################################################      
############################################################################## 

def get_depol_data(PathToFile,i):
    
    abf = pyabf.ABF(PathToFile)
    abf.setSweep(i+10)


    Time = abf.sweepX
    Time = Time*1000
    Voltage = abf.sweepY
    stim_start = 2312
    stim_end = 12312
    trace = {}
    trace['T'] = Time
    trace['V'] = Voltage
    trace['stim_start'] = [stim_start]
    trace['stim_end'] = [stim_end]
    traces = [trace]

    features = efel.getFeatureValues(traces, ["inv_time_to_first_spike",
                                              "inv_last_ISI","Spikecount",
                                              "Spikecount_stimint",
                                              "AP_amplitude","AP1_amp",
                                              "AP2_amp","APlast_amp",
                                              "voltage_base","AHP_depth_abs",
                                              "AHP_depth_abs_slow",
                                              "AHP_slow_time","AHP_depth",
                                              "AHP_time_from_peak",
                                              "AP_duration_half_width",
                                              "AP_width",
                                              "steady_state_voltage_stimend",
                                              "steady_state_voltage",
                                              "decay_time_constant_after_stim",
                                              ])



    inv_time_to_first_spike = features[0]["inv_time_to_first_spike"]
    if inv_time_to_first_spike is None:
        inv_time_to_first_spike = 0
    else: 
        inv_time_to_first_spike = features[0]["inv_time_to_first_spike"][0]    
        
    inv_last_ISI = features[0]["inv_last_ISI"]
    if inv_last_ISI is None:
        inv_last_ISI = 0
    else: 
        inv_last_ISI = features[0]["inv_last_ISI"][0]  
        
    Spikecount = features[0]["Spikecount"]
    if Spikecount is None:
        Spikecount = 0
    else: 
        Spikecount = features[0]["Spikecount"][0]  
        
    Spikecount_stimint = features[0]["Spikecount_stimint"]
    if Spikecount_stimint is None:
        Spikecount_stimint = 0
    else: 
        Spikecount_stimint = features[0]["Spikecount_stimint"][0]  
        
    AP_amplitude = features[0]["AP_amplitude"]
    if AP_amplitude is None:
        AP_amplitude = 0
    else: 
        AP_amplitude = features[0]["AP_amplitude"][0]  
        
    # AP1_amp = features[0]["AP1_amp"]
    # if AP1_amp is []:
    #     AP1_amp = 0
    # else: 
    #     AP1_amp = features[0]["AP1_amp"][0]  
        
    # AP2_amp = features[0]["AP2_amp"]
    # if AP2_amp is []:
    #     AP2_amp = 0
    # else: 
    #     AP2_amp = features[0]["AP2_amp"][0]  
    
    # APlast_amp = features[0]["APlast_amp"]
    # if  APlast_amp is []:
    #      APlast_amp = 0
    # else: 
    #      APlast_amp = features[0]["APlast_amp"][0]  
        
    voltage_base = features[0]["voltage_base"]
    if voltage_base is None:
        voltage_base = 0
    else: 
        voltage_base = features[0]["voltage_base"][0]  
    
    AHP_depth_abs = features[0]["AHP_depth_abs"]
    if AHP_depth_abs is None:
        AHP_depth_abs = 0
    else: 
        AHP_depth_abs = features[0]["AHP_depth_abs"][0]  
        
    AHP_depth_abs_slow = features[0]["AHP_depth_abs_slow"]
    if AHP_depth_abs_slow is None:
        AHP_depth_abs_slow = 0
    else: 
        AHP_depth_abs_slow = features[0]["AHP_depth_abs_slow"][0]  
        
    AHP_slow_time = features[0]["AHP_slow_time"]
    if AHP_slow_time is None:
        AHP_slow_time = 0
    else: 
        AHP_slow_time = features[0]["AHP_slow_time"][0]  
        
    AHP_depth = features[0]["AHP_depth"]
    if AHP_depth is None:
        AHP_depth = 0
    else: 
        AHP_depth = features[0]["AHP_depth"][0]
        
    AHP_time_from_peak = features[0]["AHP_time_from_peak"]
    if AHP_time_from_peak is None:
        AHP_time_from_peak = 0
    else: 
        AHP_time_from_peak = features[0]["AHP_time_from_peak"][0]  
        
    # AP_duration_half_width = features[0]["AP_duration_half_width"]
    # if AP_duration_half_width is None:
    #     AP_duration_half_width = 0
    # else: 
    #     AP_duration_half_width = features[0]["AP_duration_half_width"][0]
        
    AP_width = features[0]["AP_width"]
    if AP_width is None:
        AP_width = 0
    else: 
        AP_width = features[0]["AP_width"][0]  
        
    steady_state_voltage_stimend = features[0]["steady_state_voltage_stimend"]
    if steady_state_voltage_stimend is None:
        steady_state_voltage_stimend = 0
    else: 
        steady_state_voltage_stimend = features[0]["steady_state_voltage_stimend"][0]  
        
    steady_state_voltage = features[0]["steady_state_voltage"]
    if steady_state_voltage is None:
        steady_state_voltage = 0
    else: 
        steady_state_voltage = features[0]["steady_state_voltage"][0]  
        
    decay_time_constant_after_stim = features[0]["decay_time_constant_after_stim"]
    if decay_time_constant_after_stim is None:
        decay_time_constant_after_stim = 0
    else: 
        decay_time_constant_after_stim = features[0]["decay_time_constant_after_stim"][0]  
    
    return inv_time_to_first_spike, inv_last_ISI, Spikecount, Spikecount_stimint, \
        AP_amplitude, \
        voltage_base, AHP_depth_abs, \
        AHP_depth_abs_slow, AHP_slow_time, AHP_depth, AHP_time_from_peak, \
        AP_width, steady_state_voltage_stimend, \
        steady_state_voltage, decay_time_constant_after_stim
    
    
      # AP_duration_half_width,