#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue May 18 08:25:21 2021

@author: danielchapman
"""

def _evaluate_invalid_fitness_minus_SDs_with_features(toolbox, population,
                                                      gen_index=None, numSDs=0):
    '''Evaluate the individuals with an invalid fitness

    Returns the count of individuals with invalid fitness

    Before saving the fitness values, this method subtracts
    numSDs from each fitness value returned by efel, with a
    minimum fitness score of 0 - so it flattens the error
    function within an 'acceptable' number of SDs

    Not only saves fitness values to ind.fitnes.values, also
    saves raw feature scores to ind.fitness.features
    '''
    invalid_ind = [ind for ind in population if not ind.fitness.valid]
    from functools import partial
    execute = partial(toolbox.evaluate_with_features, gen_index=gen_index)
    # third argument (ind_index) is not accepted by pool.map
    fitness_dicts = toolbox.map(execute, invalid_ind)
    for ind, fit in zip(invalid_ind, fitness_dicts):
        errlst = list(fit['scores'].values())
        for i, item in enumerate(errlst):
            errlst[i] -= numSDs
            if errlst[i] < 0.0:
                errlst[i] = 0.0
        ind.fitness.values = tuple(errlst)
        ind.fitness.feature_values = fit['feature_values']

    return len(invalid_ind)