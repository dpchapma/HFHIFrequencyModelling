#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Mar  4 07:12:41 2021

@author: danielchapman
"""
##############################################################################      
############################################################################## 
##############################################################################      
##############################################################################  

## THIS SCRIPT GETS OUTPUT FROM CCIV hyperpolarizing DATA USING efel        ##

##############################################################################      
############################################################################## 
##############################################################################      
##############################################################################

#%%
##############################################################################      
##############################################################################   
     
        ### Import Modules
        
##############################################################################      
############################################################################## 
import pyabf
import numpy as np
import matplotlib.pyplot as plt 
import efel

#%%
##############################################################################      
##############################################################################   
     
        ### Define function to get data from hyperpolarizing steps using efel
        
##############################################################################      
############################################################################## 

def get_hyperpol_data(PathToFile,i):
    abf = pyabf.ABF(PathToFile)
    abf.setSweep(i)


    Time = abf.sweepX
    Time = Time*10000
    Voltage = abf.sweepY
    stim_start = 2312
    stim_end = 12312
    trace = {}
    trace['T'] = Time
    trace['V'] = Voltage
    trace['stim_start'] = [stim_start]
    trace['stim_end'] = [stim_end]
    traces = [trace]

    features = efel.getFeatureValues(traces,['steady_state_voltage_stimend',
                                     'steady_state_voltage','voltage_base',
                                     'decay_time_constant_after_stim','minimum_voltage',
                                     'sag_amplitude','sag_ratio1','sag_ratio2',
                                     'ohmic_input_resistance',
                                     'ohmic_input_resistance_vb_ssse'])

    steady_state_voltage_stimend = features[0]["steady_state_voltage_stimend"]
    if steady_state_voltage_stimend is None:
        steady_state_voltage_stimend = 0
    else:
        steady_state_voltage_stimend = features[0]["steady_state_voltage_stimend"][0]
    
    
    steady_state_voltage = features[0]["steady_state_voltage"][0]
    
    
    voltage_base = features[0]["voltage_base"][0]
    decay_time_constant_after_stim = features[0]["decay_time_constant_after_stim"][0]
    minimum_voltage = features[0]["minimum_voltage"]
    if minimum_voltage is None:
        minimum_voltage = 0
    else:
        minimum_voltage = features[0]["minimum_voltage"][0]

    sag_amplitude = features[0]["sag_amplitude"]
    if sag_amplitude is None:
        sag_amplitude = 0
    else:
        sag_amplitude = features[0]["sag_amplitude"][0]
        
        
    sag_ratio1 = features[0]["sag_ratio1"]
    if sag_ratio1 is None:
        sag_ratio1 = 0
    else:
        sag_ratio1 = features[0]["sag_ratio1"][0]
        
        
    sag_ratio2 = features[0]["sag_ratio2"]
    if sag_ratio2 is None:
        sag_ratio2 = 0
    else:
        sag_ratio2 = features[0]["sag_ratio2"][0]
        
    ohmic_input_resistance = features[0]["ohmic_input_resistance"]
    if ohmic_input_resistance is None:
        ohmic_input_resistance = 0
    else:
        ohmic_input_resistance = features[0]["ohmic_input_resistance"][0]
        
    ohmic_input_resistance_vb_ssse = features[0]["ohmic_input_resistance_vb_ssse"]
    if ohmic_input_resistance_vb_ssse is None:
        ohmic_input_resistance_vb_ssse = 0
    else:
        ohmic_input_resistance_vb_ssse = features[0]["ohmic_input_resistance_vb_ssse"][0]
        
    # voltage_deflection_vb_ssse = features[0]["voltage_deflection_vb_ssse"]
    # if voltage_deflection_vb_ssse is None:
    #     voltage_deflection_vb_ssse = 0
    # else:
    #     voltage_deflection_vb_ssse = features[0]["voltage_deflection_vb_ssse"][0]
    
    return steady_state_voltage_stimend, steady_state_voltage, voltage_base,\
        decay_time_constant_after_stim, minimum_voltage, sag_amplitude, sag_ratio1,\
        sag_ratio2, ohmic_input_resistance, ohmic_input_resistance_vb_ssse
        # voltage_deflection_vb_ssse
    
    
    
