#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Jan  5 12:43:31 2021

@author: danielchapman
"""
##############################################################################      
############################################################################## 
##############################################################################      
##############################################################################  

## THIS SCRIPT EVALUATES GENETIC ALGORITHM                                  ##
## code modified from bluebrain EFEL github                                 ##

##############################################################################      
############################################################################## 
##############################################################################      
##############################################################################

#%% 
##############################################################################      
##############################################################################   
     
        ### Import Modules
        
##############################################################################      
############################################################################## 
import numpy as np
import random
import numpy
import deap
import deap.gp
import deap.benchmarks
from deap import base
from deap import creator
from deap import tools
from deap import algorithms
# from VisualizeFinalPopData import Visualize_data
from scoop import futures
# import multiprocessing
# from neuron import h,load_mechanisms,hclass

import faulthandler
faulthandler.enable()

#%%
##############################################################################      
##############################################################################   
     
        ### Get experimental data
        
##############################################################################      
############################################################################## 
# from GetData import get_data
# PathToFolder ='/Users/danielchapman/Desktop/StephCCDat/Sham/'
# ExpData = get_data(PathToFolder)

#%%
##############################################################################      
##############################################################################   
     
        ### SETUP ALGORITHM PARAMETERS
        
##############################################################################      
############################################################################## 
Rand = random.randint(1,50)
random.seed(Rand)

POP_SIZE = 200
# Number of offspring in every generation
OFFSPRING_SIZE = 200
# Number of generations0
NGEN = 500
# The parent and offspring population size are set the same
MU = 200
LAMBDA = OFFSPRING_SIZE
# Crossover probability
CXPB = 0.3
# Mutation probability, should sum to one together with CXPB
MUTPB = 0.7
# Eta parameter of cx and mut operators
ETA = 0.1

Jitter = 0.1

IND_SIZE = 15


##############################################################################      
##############################################################################   
     
        ### SET BOUNDS FOR EACH CHANNEL PARAMETER
        
##############################################################################      
############################################################################## 

LOWER = [20, # soma ra
        0.1 , # cm
        20000, # Rm
        -80, # Vleak
        0.000001, # gnaSoma
        0.000001, # gkdr
        0.000001, # gkap
        0.00000001, # soma caL
        0.00000001, # soma caR
        0.00000001, # soma caN
        0.00000001, # soma caT
        0.00000001, # hbar
        0.00000001, # soma km
        0.00000001, # soma kdBG
        0.00000001] # soma KCA


UPPER = [150, # soma ra
        1.5 , # cm
        40000, # Rm
        -60, # Vleak
        0.5, # gnaSoma
        0.1, # gkdr
        0.1, # gkap
        0.01, # soma caL
        0.01, # soma caR
        0.01, # soma caN
        0.01, # soma caT
        0.01, # hbar
        0.01, # soma km
        0.01, # soma kdBG
        0.01] # soma KCA

##############################################################################      
##############################################################################   
     
        ### SET TOOLBOXES
        
##############################################################################      
############################################################################## 
FeatureNumber = 17

SELECTOR = "NSGA-II"
creator.create("Fitness", base.Fitness, weights=[-1.0] * FeatureNumber)
creator.create("Individual", list, fitness=creator.Fitness)

def uniform(lower_list, upper_list, dimensions):
    """Fill array """

    if hasattr(lower_list, '__iter__'):
        return [random.uniform(lower, upper) for lower, upper in
                zip(lower_list, upper_list)]
    else:
        return [random.uniform(lower_list, upper_list)
                for _ in range(dimensions)]

    
    
    
# def pop_start(PathToFile):
#     pop_params = np.genfromtxt(PathToFile, delimiter=',')
#     pop_start
#     return pop_params[:,4]


toolbox = base.Toolbox()    
toolbox.register("uniformparams", uniform, LOWER, UPPER, IND_SIZE)

# pool = multiprocessing.Pool()
# toolbox.register("map", pool.map)
toolbox.register("map", futures.map)
# toolbox.register("pop_start",pop_start,'/Users/danielchapman/PythonDev/Final/Models/01.28.21Params100GenTwoStimCaParam.csv')


toolbox.register(
    "Individual",
    tools.initIterate,
    creator.Individual,
    toolbox.uniformparams)


# toolbox.register(
#     "Individual",
#     tools.initIterate,
#     creator.Individual,
#     toolbox.pop_start)

toolbox.register("population", tools.initRepeat, list, toolbox.Individual)

from EvaluateFunction import evaluate
toolbox.register("evaluate", evaluate)

toolbox.register(
    "mate",
    deap.tools.cxSimulatedBinaryBounded,
    eta=ETA,
    low=LOWER,
    up=UPPER)
toolbox.register("mutate", deap.tools.mutPolynomialBounded, eta=ETA,
                 low=LOWER, up=UPPER, indpb=0.1)
toolbox.register(
    "select",
    tools.selNSGA2_featcrowd)


#%%
##############################################################################      
##############################################################################   
     
        ### SET FITNESS VALUES
        
##############################################################################      
############################################################################## 

first_stats = tools.Statistics(key=lambda ind: ind.fitness.values[0])
second_stats = tools.Statistics(key=lambda ind: ind.fitness.values[1])
third_stats = tools.Statistics(key=lambda ind: ind.fitness.values[2])
fourth_stats = tools.Statistics(key=lambda ind: ind.fitness.values[3])
fifth_stats = tools.Statistics(key=lambda ind: ind.fitness.values[4])
sixth_stats = tools.Statistics(key=lambda ind: ind.fitness.values[5])
seventh_stats = tools.Statistics(key=lambda ind: ind.fitness.values[6])
eighth_stats = tools.Statistics(key=lambda ind: ind.fitness.values[7])
ninth_stats = tools.Statistics(key=lambda ind: ind.fitness.values[8])
tenth_stats = tools.Statistics(key=lambda ind: ind.fitness.values[9])
eleventh_stats = tools.Statistics(key=lambda ind: ind.fitness.values[10])
twelfth_stats = tools.Statistics(key=lambda ind: ind.fitness.values[11])
thirteenth_stats = tools.Statistics(key=lambda ind: ind.fitness.values[12])
fourteenth_stats = tools.Statistics(key=lambda ind: ind.fitness.values[13])
fifteenth_stats = tools.Statistics(key=lambda ind: ind.fitness.values[14])
sixteenth_stats = tools.Statistics(key=lambda ind: ind.fitness.values[15])
seventeenth_stats = tools.Statistics(key=lambda ind: ind.fitness.values[16])
# eighteenth_stats = tools.Statistics(key=lambda ind: ind.fitness.values[17])
# nineteenth_stats = tools.Statistics(key=lambda ind: ind.fitness.values[18])
# twentieth_stats = tools.Statistics(key=lambda ind: ind.fitness.values[19])
# twentyfirst_stats = tools.Statistics(key=lambda ind: ind.fitness.values[20])
# twentysecond_stats = tools.Statistics(key=lambda ind: ind.fitness.values[21])
# twentythird_stats = tools.Statistics(key=lambda ind: ind.fitness.values[22])
# twentyfourth_stats = tools.Statistics(key=lambda ind: ind.fitness.values[23])
# twentyfifth_stats = tools.Statistics(key=lambda ind: ind.fitness.values[24])
# twentysixth_stats = tools.Statistics(key=lambda ind: ind.fitness.values[25])
# twentyseventh_stats = tools.Statistics(key=lambda ind: ind.fitness.values[26])
# twentyeigth_stats = tools.Statistics(key=lambda ind: ind.fitness.values[27])
# twentyninth_stats = tools.Statistics(key=lambda ind: ind.fitness.values[28])
# thirtieth_stats = tools.Statistics(key=lambda ind: ind.fitness.values[29])
# thirtyfirst_stats = tools.Statistics(key=lambda ind: ind.fitness.values[30])
# thirtysecond_stats = tools.Statistics(key=lambda ind: ind.fitness.values[31])
# thirtythird_stats = tools.Statistics(key=lambda ind: ind.fitness.values[32])
# thirtyfourth_stats = tools.Statistics(key=lambda ind: ind.fitness.values[33])
# thirtyfifth_stats = tools.Statistics(key=lambda ind: ind.fitness.values[34])
# thirtysixth_stats = tools.Statistics(key=lambda ind: ind.fitness.values[35])
# thirtyseventh_stats = tools.Statistics(key=lambda ind: ind.fitness.values[36])
# thirtyeighth_stats = tools.Statistics(key=lambda ind: ind.fitness.values[37])
# thirtyninth_stats = tools.Statistics(key=lambda ind: ind.fitness.values[38])
# fortieth_stats = tools.Statistics(key=lambda ind: ind.fitness.values[39])
# fortyfirst_stats = tools.Statistics(key=lambda ind: ind.fitness.values[40])
# fortysecond_stats = tools.Statistics(key=lambda ind: ind.fitness.values[41])
# fortythird_stats = tools.Statistics(key=lambda ind: ind.fitness.values[42])
# fortyfourth_stats = tools.Statistics(key=lambda ind: ind.fitness.values[43])
# fortyfifth_stats = tools.Statistics(key=lambda ind: ind.fitness.values[44])
# fortysixth_stats = tools.Statistics(key=lambda ind: ind.fitness.values[45])
# fortyseventh_stats = tools.Statistics(key=lambda ind: ind.fitness.values[46])
# fortyeighth_stats = tools.Statistics(key=lambda ind: ind.fitness.values[47])
# fortynineth_stats = tools.Statistics(key=lambda ind: ind.fitness.values[48])
# fiftieth_stats = tools.Statistics(key=lambda ind: ind.fitness.values[49])
# fiftyfirst_stats = tools.Statistics(key=lambda ind: ind.fitness.values[50])
# fiftysecond_stats = tools.Statistics(key=lambda ind: ind.fitness.values[51])
# fiftythird_stats = tools.Statistics(key=lambda ind: ind.fitness.values[52])
# fiftyfourth_stats = tools.Statistics(key=lambda ind: ind.fitness.values[53])
# fiftyfifth_stats = tools.Statistics(key=lambda ind: ind.fitness.values[54])
# fiftysixth_stats = tools.Statistics(key=lambda ind: ind.fitness.values[55])
# fiftyseventh_stats = tools.Statistics(key=lambda ind: ind.fitness.values[56])
# fiftyeigth_stats = tools.Statistics(key=lambda ind: ind.fitness.values[57])
# fiftyninth_stats = tools.Statistics(key=lambda ind: ind.fitness.values[58])
# sixtieth_stats = tools.Statistics(key=lambda ind: ind.fitness.values[59])
# sixtyfirst_stats = tools.Statistics(key=lambda ind: ind.fitness.values[60])
# sixtysecond_stats = tools.Statistics(key=lambda ind: ind.fitness.values[61])
# sixtythird_stats = tools.Statistics(key=lambda ind: ind.fitness.values[62])
# sixtyfourth_stats = tools.Statistics(key=lambda ind: ind.fitness.values[63])
# sixtyfifth_stats = tools.Statistics(key=lambda ind: ind.fitness.values[64])
# sixtysixth_stats = tools.Statistics(key=lambda ind: ind.fitness.values[65])
# sixtyseventh_stats = tools.Statistics(key=lambda ind: ind.fitness.values[66])
# sixtyeighth_stats = tools.Statistics(key=lambda ind: ind.fitness.values[67])
# sixtyninth_stats = tools.Statistics(key=lambda ind: ind.fitness.values[68])
# seventieth_stats = tools.Statistics(key=lambda ind: ind.fitness.values[69])
# seventyfirst_stats = tools.Statistics(key=lambda ind: ind.fitness.values[70])
# seventysecond_stats = tools.Statistics(key=lambda ind: ind.fitness.values[71])
# seventythird_stats = tools.Statistics(key=lambda ind: ind.fitness.values[72])
# seventyfourth_stats = tools.Statistics(key=lambda ind: ind.fitness.values[73])
# seventyfifth_stats = tools.Statistics(key=lambda ind: ind.fitness.values[74])
# seventysixth_stats = tools.Statistics(key=lambda ind: ind.fitness.values[75])
# seventyseventh_stats = tools.Statistics(key=lambda ind: ind.fitness.values[76])
# seventyeighth_stats = tools.Statistics(key=lambda ind: ind.fitness.values[77])
# seventynineth_stats = tools.Statistics(key=lambda ind: ind.fitness.values[78])
# eightieth_stats = tools.Statistics(key=lambda ind: ind.fitness.values[79])
# eightyfirst_stats = tools.Statistics(key=lambda ind: ind.fitness.values[80])
# eightysecond_stats = tools.Statistics(key=lambda ind: ind.fitness.values[81])
# eightythird_stats = tools.Statistics(key=lambda ind: ind.fitness.values[82])
# eightyfourth_stats = tools.Statistics(key=lambda ind: ind.fitness.values[83])
# eightyfifth_stats = tools.Statistics(key=lambda ind: ind.fitness.values[84])
# eightysixth_stats = tools.Statistics(key=lambda ind: ind.fitness.values[85])
# eightyseventh_stats = tools.Statistics(key=lambda ind: ind.fitness.values[86])
# eightyeigth_stats = tools.Statistics(key=lambda ind: ind.fitness.values[87])
# eightyninth_stats = tools.Statistics(key=lambda ind: ind.fitness.values[88])
# ninetieth_stats = tools.Statistics(key=lambda ind: ind.fitness.values[89])
# ninetyfirst_stats = tools.Statistics(key=lambda ind: ind.fitness.values[90])
# ninetysecond_stats = tools.Statistics(key=lambda ind: ind.fitness.values[91])
# ninetythird_stats = tools.Statistics(key=lambda ind: ind.fitness.values[92])
# ninetyfourth_stats = tools.Statistics(key=lambda ind: ind.fitness.values[93])
# ninetyfifth_stats = tools.Statistics(key=lambda ind: ind.fitness.values[94])
# ninetysixth_stats = tools.Statistics(key=lambda ind: ind.fitness.values[95])
# ninetyseventh_stats = tools.Statistics(key=lambda ind: ind.fitness.values[96])
# ninetyeighth_stats = tools.Statistics(key=lambda ind: ind.fitness.values[97])
# ninetyninth_stats = tools.Statistics(key=lambda ind: ind.fitness.values[98])
# hundredth_stats = tools.Statistics(key=lambda ind: ind.fitness.values[99])
# hundredfirst_stats = tools.Statistics(key=lambda ind: ind.fitness.values[100])

# stats = tools.Statistics(obj1=first_stats)
stats = tools.MultiStatistics(obj1 = first_stats, obj2 = second_stats,
                                obj3 = third_stats, obj4 = fourth_stats,
                                obj5 = fifth_stats,obj6 = sixth_stats,
                                obj7 = seventh_stats,obj8 = eighth_stats, 
                                obj9 =  ninth_stats, obj10 = tenth_stats,
                                obj11 = eleventh_stats, 
                                obj12 = twelfth_stats,obj13 = thirteenth_stats,
                                obj14 = fourteenth_stats, obj15 = fifteenth_stats,
                                obj16 = sixteenth_stats,
                                obj17 = seventeenth_stats)
                                # obj18 = eighteenth_stats, obj19 = nineteenth_stats, 
                                # obj20 = twentieth_stats) 
                                # obj21 = twentyfirst_stats) 
#                                 obj22 = twentysecond_stats, obj23 = twentythird_stats, 
#                                 obj24 = twentyfourth_stats,obj25 = twentyfifth_stats, 
#                                 obj26 = twentysixth_stats,obj27 = twentyseventh_stats, 
#                                 obj28 = twentyeigth_stats,obj29 = twentyninth_stats,
#                                 obj30 = thirtieth_stats,
#                                 obj31 = thirtyfirst_stats,
#                                 obj32 = thirtysecond_stats,
#                                 obj33 = thirtythird_stats,
#                                 obj34 = thirtyfourth_stats,
#                                 obj35 = thirtyfifth_stats,
#                                 obj36 = thirtysixth_stats,
#                                 obj37 = thirtyseventh_stats,
#                                 obj38 = thirtyeighth_stats,
#                                 obj39 = thirtyninth_stats,
#                                 obj40 = fortieth_stats,
#                                 obj41 = fortyfirst_stats,
#                                 obj42 = fortysecond_stats,
#                                 obj43 = fortythird_stats,
#                                 obj44 = fortyfourth_stats,
#                                 obj45 = fortyfifth_stats,
#                                 obj46 = fortysixth_stats,
#                                 obj47 = fortyseventh_stats,
#                                 obj48 = fortyeighth_stats,
#                                 obj49 = fortynineth_stats,
#                                 obj50 = fiftieth_stats,
#                                 obj51 = fiftyfirst_stats,
#                                 obj52 = fiftysecond_stats,
#                                 obj53 = fiftythird_stats,
#                                 obj54 = fiftyfourth_stats,
#                                 obj55 = fiftyfifth_stats,
#                                 obj56 = fiftysixth_stats,
#                                 obj57 = fiftyseventh_stats,
#                                 obj58 = fiftyeigth_stats,
#                                 obj59 = fiftyninth_stats,
#                                 obj60 = sixtieth_stats,
#                                 obj61 = sixtyfirst_stats,
#                                 obj62 = sixtysecond_stats,
#                                 obj63 = sixtythird_stats,
#                                 obj64 = sixtyfourth_stats,
#                                 obj65 = sixtyfifth_stats,
#                                 obj66 = sixtysixth_stats,
#                                 obj67 = sixtyseventh_stats,
#                                 obj68 = sixtyeighth_stats,
#                                 obj69 = sixtyninth_stats,
#                                 obj70 = seventieth_stats,
#                                 obj71 = seventyfirst_stats,
#                                 obj72 = seventysecond_stats,
#                                 obj73 = seventythird_stats,
#                                 obj74 = seventyfourth_stats,
#                                 obj75 = seventyfifth_stats,
#                                 obj76 = seventysixth_stats,
#                                 obj77 = seventyseventh_stats,
#                                 obj78 = seventyeighth_stats,
#                                 obj79 = seventynineth_stats ,
#                                 obj80 = eightieth_stats,
#                                 obj81 = eightyfirst_stats,
#                                 obj82 = eightysecond_stats,
#                                 obj83 = eightythird_stats,
#                                 obj84 = eightyfourth_stats,
#                                 obj85 = eightyfifth_stats,
#                                 obj86 = eightysixth_stats,
#                                 obj87 = eightyseventh_stats,
#                                 obj88 = eightyeigth_stats,
#                                 obj89 = eightyninth_stats,
#                                 obj90 = ninetieth_stats,
#                                 obj91 = ninetyfirst_stats,
#                                 obj92 = ninetysecond_stats,
#                                 obj93 = ninetythird_stats,
#                                 obj94 = ninetyfourth_stats,
#                                 obj95 = ninetyfifth_stats,
#                                 obj96 = ninetysixth_stats,
#                                 obj97 = ninetyseventh_stats,
#                                 obj98 = ninetyeighth_stats,
#                                 obj99 = ninetyninth_stats,
#                                 obj100 = hundredth_stats,
#                                 obj101 = hundredfirst_stats)

#%%
logbook = tools.Logbook()
pop = toolbox.population(n=MU)
stats.register("min", numpy.min,axis=0)
# stats.register("avg", numpy.mean,axis=0)
stats.register("all", numpy.array)
hofNum = 10000
hof = tools.HallOfFame(hofNum)


#%% have to run everything from a main to allow for parallel processing 
if __name__ == '__main__':
    # run the algorithm
    # pop, logbook = algorithms.eaMuPlusLambda(
    #     pop,
    #     toolbox,
    #     MU,
    #     LAMBDA,
    #     CXPB,
    #     MUTPB,
    #     NGEN,
    #     stats,
    #     halloffame=hof)
    
    pop, logbook = algorithms.ChapAlgorithm(
        pop,
        toolbox,
        MU,
        Jitter,
        CXPB,
        MUTPB,
        NGEN,
        LOWER,
        UPPER,
        stats,
        halloffame=hof)    
    
    # save the parameters from the hall of fame only
    # params = np.empty([IND_SIZE,MU])
    # for i in range(0,MU):
    #     params[0:IND_SIZE,i] = pop[i]
        
        
    hofparams = np.empty([IND_SIZE,hofNum])
    for i in range(0,hofNum):
        hofparams[0:IND_SIZE,i] = hof[i]
    # np.savetxt("Ball100MSGenTestParams.csv",params,delimiter=",")
    np.savetxt("Ball1000MSGenTestHofParams.csv",hofparams,delimiter=",")
    
    # save error data
    # ErrorMins = np.zeros([NGEN+1,FeatureNumber+1])
    ErrorAvg = np.zeros([NGEN+1,FeatureNumber+1])
    
    for x in range(1,FeatureNumber+1):
        # ErrorMins[:,x] = logbook.chapters['obj{}'.format(x)].select('min')
        ErrorAvg[:,x] = logbook.chapters['obj{}'.format(x)].select('avg')
    
    # ErrorMins = np.zeros([FeatureNumber,NGEN])
    # ErrorMins = logbook.select('min')
    np.savetxt("Ball1000MSGenTestAvg.csv",ErrorAvg,delimiter=",")
    


    ErrorAll = np.zeros([FeatureNumber,hofNum])
    AllDummy = stats.compile(hof)
    # ErrorAll = AllDummy['all']
    for Err in range(1,FeatureNumber):      
        ErrorAll[Err-1,:] = AllDummy['obj{}'.format(Err)]['all']
    np.savetxt("Ball1000MSGenTestHofErr.csv",ErrorAll,delimiter=",")


# blah = stats.compile(hof)    
# blah['obj1']['all']

    
    
    
    
    
    
    
    
    



    





